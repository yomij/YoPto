<template>
  <div class="big-photo" v-show="isShow" @click.self = "isShow = false">
	<div class="img-container">
		<div class="top">
			浙江 杭州
		</div>
		<div class="content">
		<div class="middle">
			<img @click="isEnlarge = !isEnlarge" :class="{enlarge: isEnlarge}" :src="imgOb.smallUrl"/>
		</div>
		<div class="bottom">
			后来，我的梦境总是反复出现这场无声无息的火，无数飞虫朝它飞去，它们仿佛是早就存在于这个世界的记忆碎片，旧时尘埃。
		</div>
		</div>
	</div>
  </div>
</template>

<script>
export default {
  name: 'big-photo',
  props: {
  	imgOb: {
  		default: () => {},
  		type: Object
  	}
  },
  data () {
    return {
    	isEnlarge: false,
    	isShow: false
    }
  },
  created(){
  	document.body.className = 'modal-body'
  },
  methods: {
    
  },
  watch: {
  	isShow(val) {
  		if(val) {
  			// alert(val)
  			document.body.className = 'modal-body'
  		} else {
  			document.body.className = ''
  		}
  	},
  	imgOb(val) {
  		this.isShow = true;
  	}
  }
}
</script>

<style scoped lang="scss">
@media screen and (min-width: 770px){
	.big-photo {
		padding: 0 80px;
	}
}
@media screen and (min-width: 1400px){
	.big-photo {
		padding: 0 120px;
	}
}

.big-photo {
	position: fixed;
	top: 0;
	left: 0;
	z-index: 5000;
	background-color: rgba(0, 0, 0, .6);
	overflow: auto;
	width: 100%;
	height: 100%;
	.img-container {
		width: 100%;
		position: relative;
		padding-top: 20px;
		height: 100%;
		.content {
			position: relative;
			height: 100%;
			width: 100%;
			padding: 0 0 80px 0;
		}
		.top {
			position: -webkit-sticky;
			position: sticky;
			width: 100%;
			height: 62px;
		    top: 0;
		    border-top-left-radius: 4px;
		    border-top-right-radius: 4px;
		    overflow: hidden;
			background-color: #fff;
			z-index: 1;
		}
		.middle {
			position: relative;
			width: 100%;
			background-color: #fff;
			text-align: center;
			// min-height: 100%;
			img {
				position:relative;
				margin:0 auto;

				cursor: zoom-in;
				&.enlarge {
					width: 100%;
					cursor: zoom-out;
					height: auto;
				}
			}
		}
		.bottom {
			position: relative;
			bottom: 0px;
			border-bottom-left-radius: 4px;
		    border-bottom-right-radius: 4px;
		    background: #fff;
		    // height: 80px;
		    width: 100%;

		}
	}
}
</style>
