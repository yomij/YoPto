<template>
  <div class="y-header">
      
      <ul class="nav">
        <li><a class="link" href="">Yomi</a></li>
        <li><router-link class="link" :to="{name: 'AsPhotographer'}">Photographer</router-link></li>
        <li><a class="link" href="">Programmer</a></li>
        <li><a class="link" href="">Music Lover</a></li>
        <li><a class="link" href="">About</a></li>
        <li><a class="button-common contact">Contact Yomi</a></li>
      </ul>
  </div>
</template>

<script>
export default {
  name: 'YHeader',
  data () {
    return {
    }
  },
  methods: {
    
  }
}
</script>

<style scoped lang="scss">
.y-header {
    height: 62px;
    background-color: #fff;
    // line-height: 62px;
    .nav {
        .link {
            color: #999;
            float: left;
            padding: 19px 12px;
            height: 100%;
            transition: color .2s ease-in-out,opacity .2s ease-in-out;
            &:hover {
                color: #111;
            }
        }
        .contact {
            @extend .button-common;
            box-shadow: 0 1px 4px rgba(0,0,0,0.02), 0 1px 1px rgba(0,0,0,0.06);
            border: 1px solid #dddddd;
            top: 12px;
            margin-bottom: 0;

            &:hover {
                border: 1px solid #bbb;
                color: #111;
            }
        }

    }
}


@media screen and (max-width: 800px){

}

@media only screen and (min-width: 800px) {
    .example {background: green;}
}
</style>
