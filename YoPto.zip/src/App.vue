<template>
  <div id="app">
    <y-header></y-header>
    <router-view/>
  </div>
</template>

<script>
import YHeader from './components/YHeader'
export default {
  name: 'App',
  components: {
    YHeader
  }
}
</script>

<style>
#app {
  font-family: '-apple-system','BlinkMacSystemFont','San Francisco','Helvetica Neue','Helvetica','Ubuntu','Roboto','Noto','Segoe UI','Arial','sans-serif';
  font-size: 15px;
  font-weight: 400;
  line-height: 1.6;
  color: #111;
  width: 100%;
  min-height: 100%;
  padding: 0;
  margin: 0;
}
</style>
